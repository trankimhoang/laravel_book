<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    //"image" là tên bảng trong database
    protected $table = "image";
    
}


